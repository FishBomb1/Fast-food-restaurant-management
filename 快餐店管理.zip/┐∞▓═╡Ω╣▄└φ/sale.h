#pragma once
#include"common.h"
#include"menu.h"

struct dish s_table[50];
struct dish temp;
void p_sale();